angular.module('app.controllers', [])
  
.controller('boasVindasCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('loginCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('diarioDeBordoCtrl', ['$scope', '$stateParams', '$ionicModal','HttpService','$timeout', '$ionicLoading', '$filter', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $ionicModal, HttpService, $timeout, $ionicLoading, $filter) {

	//loading da pagina

	function processar(){
		$ionicLoading.show({
	      content: 'Loading',
	      animation: 'fade-in',
	      showBackdrop: true,
	      maxWidth: 200,
	      showDelay: 0
	    });
	  };

    function fecharProcessamento(){    
    	$ionicLoading.hide();
	}
/*
    $timeout(function () {
      $ionicLoading.hide();
    }, 10000);
*/

	//variaveis vazias
	$scope.novoDiario = [];

	//Veridica se tem diario em aberto
	HttpService.consultaDiario()
	   .then(function(response) {
	       diario = response[0];
	       if (diario != undefined){
	       	$scope.diario = diario;
	       }else{
	       	$scope.diario = false;
	       }
	    });
	 //buscar Frota
	 HttpService.getFrotas()
	   .then(function(response) {
	       	$scope.frotas = response;
	    });
	 //Buscar coordenada
	 HttpService.getCoordenadas()
	   .then(function(response) {
	       $scope.coordenadas = response;
	    });
	//Modal de selecionar Automovel
	$ionicModal.fromTemplateUrl('templates/cadastro/selAutomovel.html', {
	    scope: $scope
	  }).then(function(modal) {
	    $scope.modal = modal;
	  });
	  
	  $scope.openModal = function() {
	    $scope.modal.show();
	  };
	  $scope.closeModal = function() {
	    $scope.modal.hide();
	  };

	 //Modal de selecionar coordenada inicio
	$ionicModal.fromTemplateUrl('templates/cadastro/selCoordInicio.html', {
	    scope: $scope
	  }).then(function(modal) {
	    $scope.inicio = modal;
	  });
	  $scope.openCoordInicio = function(automovel) {
	  	$scope.novoDiario.aut = automovel;
	  	$scope.closeModal();
	  	$scope.inicio.show();
	  };
	  $scope.closeCoordInicio = function() {
	    $scope.inicio.hide();
	  };

	//Modal de selecionar coordenada fim
	$ionicModal.fromTemplateUrl('templates/cadastro/selCoordFim.html', {
	    scope: $scope
	  }).then(function(modal) {
	    $scope.fim = modal;
	  });
	  $scope.openCoordFim = function(ci) {
	  	$scope.novoDiario.ci = ci;
	  	$scope.closeCoordInicio();
	    $scope.fim.show();
	  };
	  $scope.closeCoordFim = function() {
	    $scope.fim.hide();
	  };

	    //Inserir Diario
	  $scope.insereDiario = function(cf){
	   	$scope.novoDiario.cf = cf;
	   	$scope.novoDiario.data = $filter('date')(new Date(), 'yyyy-MM-dd');
	   	$scope.closeCoordFim();
		//processar();
	    HttpService.insereDiario($scope.novoDiario)
	   		.then(function(response) {
	   			console.log(response);
	   			//fecharProcessamento();
	    });
	   	//Processa a pagina
		
	  };
	
}])
      
.controller('ocorrenciasCtrl', ['$scope', '$stateParams', '$ionicModal', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $ionicModal) {
	$ionicModal.fromTemplateUrl('templates/cadastro/selOcorrencias.html', {
	    scope: $scope
	  }).then(function(modal) {
	    $scope.ocorrencias = modal;
	  });
	  $scope.openOcorrencias = function() {
	  	$scope.ocorrencias.show();
	  };
	  $scope.closeOcorrencias = function() {
	    $scope.ocorrencias.hide();
	  };

}])
   
.controller('jornadasCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('registroDeJornadaCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('registroDeJornada2Ctrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('menuCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
 