angular.module('app.services', [])

.factory('BlankFactory', [function(){

}])

.service('HttpService', function($http) {
 return {
 	//Servicos Diario

 	//Inserir Diario
 	insereDiario: function(a) {
    var diario = a;
    console.log(a);
     // $http returns a promise, which has a then function, which also returns a promise.
     return $http.get('http://localhost:3000/insereDiario', a)
       .then(function(response) {
         // In the response, resp.data contains the result. Check the console to see all of the data returned.
         console.log('Inseriu a cidade', response);
         return response.data;
      });
   },
   consultaDiario: function() {
     // $http returns a promise, which has a then function, which also returns a promise.
     return $http.get('http://localhost:3000/diario')
       .then(function(response) {
       	 // In the response, resp.data contains the result. Check the console to see all of the data returned.
       	 return response.data;
      });
   },
   getFrotas: function() {
     // $http returns a promise, which has a then function, which also returns a promise.
     return $http.get('http://localhost:3000/frotas')
       .then(function(response) {
       	 // In the response, resp.data contains the result. Check the console to see all of the data returned.
       	 return response.data;
      });
   },
   getCoordenadas: function() {
     // $http returns a promise, which has a then function, which also returns a promise.
     return $http.get('http://localhost:3000/coordenadas')
       .then(function(response) {
       	 // In the response, resp.data contains the result. Check the console to see all of the data returned.
       	 return response.data;
      });
   }

};

});