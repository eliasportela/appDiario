angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('menu.boasVindas', {
    url: '/boas-vindas',
    views: {
      'side-menu21': {
        templateUrl: 'templates/boasVindas.html',
        controller: 'boasVindasCtrl'
      }
    }
  })

  .state('menu.login', {
    url: '/login',
    views: {
      'side-menu21': {
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl'
      }
    }
  })

  .state('menu.diRioDeBordo', {
    url: '/diario-de-bordo',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diRioDeBordo.html',
        controller: 'diRioDeBordoCtrl'
      }
    }
  })

  .state('jornadas', {
    url: '/jornada',
    templateUrl: 'templates/jornadas.html',
    controller: 'jornadasCtrl'
  })

  .state('diRioDeBordo2', {
    url: '/diario-de-bordo-1',
    templateUrl: 'templates/diRioDeBordo2.html',
    controller: 'diRioDeBordo2Ctrl'
  })

  .state('jornadas2', {
    url: '/jornada-1',
    templateUrl: 'templates/jornadas2.html',
    controller: 'jornadas2Ctrl'
  })

  .state('jornadas3', {
    url: '/jornada-2',
    templateUrl: 'templates/jornadas3.html',
    controller: 'jornadas3Ctrl'
  })

  .state('menu.novoDiRioDeBordo', {
    url: '/add-diario',
    views: {
      'side-menu21': {
        templateUrl: 'templates/novoDiRioDeBordo.html',
        controller: 'novoDiRioDeBordoCtrl'
      }
    }
  })

  .state('buscarAutomovel', {
    url: '/modal-buscar-automel',
    templateUrl: 'templates/buscarAutomovel.html',
    controller: 'buscarAutomovelCtrl'
  })

  .state('buscarTrajeto', {
    url: '/page10',
    templateUrl: 'templates/buscarTrajeto.html',
    controller: 'buscarTrajetoCtrl'
  })

  .state('adicionarOcorrencia', {
    url: '/add-ocorrencia',
    templateUrl: 'templates/adicionarOcorrencia.html',
    controller: 'adicionarOcorrenciaCtrl'
  })

  .state('adicionarParada', {
    url: '/add-parada',
    templateUrl: 'templates/adicionarParada.html',
    controller: 'adicionarParadaCtrl'
  })

  .state('registroDeJornada', {
    url: '/registro-jornada',
    templateUrl: 'templates/registroDeJornada.html',
    controller: 'registroDeJornadaCtrl'
  })

  .state('registroDeJornada2', {
    url: '/registro-jornada-1',
    templateUrl: 'templates/registroDeJornada2.html',
    controller: 'registroDeJornada2Ctrl'
  })

  .state('menu', {
    url: '/side-menu',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

$urlRouterProvider.otherwise('/side-menu/boas-vindas')


});